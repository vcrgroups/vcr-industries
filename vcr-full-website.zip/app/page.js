export default function Home() {
  return (
    <main className="p-10">
      <h1 className="text-5xl font-bold">VCR Group of Industries</h1>
      <p className="text-xl mt-4">A multi-sector industrial group.</p>
    </main>
  );
}